


# include<stdlib.h>
# include<netinet/in.h>
# include<time.h>
# include<arpa/inet.h>
# include<string.h>
# include<unistd.h>
# include<netdb.h>
# include<stdio.h>

int main(void)
{ 
	struct sockaddr_in serversocket;
  	int listensocket,i,connsd,size;
	char arr[100],sendbuff[100],sendbuff1[100],sendbuff2[100],recvbuff[100],recvbuff1[100],recvbuff2[100];

        printf("\This is Chat Client.\n");
        bzero((char *)&serversocket,sizeof(serversocket));

        listensocket=socket(PF_INET,SOCK_STREAM,0);

        if(listensocket<0)
                printf("Socket Could Not Be Created");
        else
                printf("Socket Created Succesfully");

        printf("\nListensocket Value : %d",listensocket);

        serversocket.sin_family=AF_INET;
        serversocket.sin_port=htons(6004);
        serversocket.sin_addr.s_addr=inet_addr("172.16.228.60");
      	i = connect(listensocket,(struct sockaddr *)&serversocket,sizeof(serversocket));

        if(i==0)
                printf("\nConnect SUCCESS\n");
        else
                printf("\nConnect ERROR\n");

        while(1)
        {
                printf("\nEnter the first number");
                fgets(sendbuff,100,stdin);
                send(listensocket,sendbuff,strlen(sendbuff),0);
                strcpy(recvbuff,"");
                 printf("\nEnter the second number");
                fgets(sendbuff1,100,stdin);
                send(listensocket,sendbuff1,strlen(sendbuff1),0);
                strcpy(recvbuff1,"");
                printf("\n 1.addition 2.substraction 3.multiplication 4.division ");
                printf("\n enter your choice");
                fgets(sendbuff2,100,stdin);
                send(listensocket,sendbuff2,strlen(sendbuff2),0);
                strcpy(recvbuff2,"");
                if((i =recv(listensocket,recvbuff,100,0))>0)
                {
                        recvbuff[i]='\0';
                        printf("\nMessage from Server#%s",recvbuff);
                }
        }

}


