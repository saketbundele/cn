


# include<stdlib.h>
# include<netinet/in.h>
# include<time.h>
# include<arpa/inet.h>
# include<string.h>
# include<unistd.h>
# include<netdb.h>
# include<stdio.h>
#include<arpa/inet.h>
#include<stdio.h>


int main()
{
        int listensocket, i, connsd, size,k,ch,j;
        struct sockaddr_in serversocket,clientsocket;
       char arr[100], sendbuff[100], recvbuff[100],sendbuff1[100], recvbuff1[100],recvbuff2[100],sendbuff2[100];

        printf("\This is Chat Server.\n");
		
		bzero((char *)&serversocket,sizeof(serversocket));

        listensocket=socket(PF_INET,SOCK_STREAM,0);

        if(listensocket<0)
                printf("Socket Could Not Be Created");
        else
                printf("Socket Created Succesfully");

        printf("\nListensocket Value : %d",listensocket);

        serversocket.sin_family=AF_INET;
        serversocket.sin_port=htons(6004);
        serversocket.sin_addr.s_addr=inet_addr("172.16.228.60 ");
        i = bind(listensocket,(struct sockaddr *) &serversocket,sizeof(serversocket));
        if(i == 0)
                printf("\nBinding Is Succesful\n");
        else
                printf("\n Binding Not Succesful\n");

        i = listen(listensocket,1);
        if(i == 0)
               printf("Listen SUCCESS\n");
        else
                printf("Listen ERROR\n");

        size = sizeof(struct sockaddr_in);

        connsd = accept(listensocket, (struct sockaddr *) &clientsocket,&size);

        while(1)
        {
               
                if((i=recv(connsd,recvbuff,100,0))>0)
                {
                	 if((k=recv(connsd,recvbuff1,100,0))>0)
                	{
                		if((j=recv(connsd,recvbuff2,100,0))>0)
                		{
                       
                        recvbuff[i]='\0';
                        recvbuff1[k]='\0';
                        recvbuff2[j]='\0';
                        int a=atoi(recvbuff);           
                       int b=atoi(recvbuff1);
                           ch=atoi(recvbuff2);
                        int ans;
                       	
                        	switch(ch)
                        	{
               				case 1:
               					ans=a+b;
               					break;
               				case 2:
               					ans=a-b;
               					break;
               				case 3:
               					ans=a*b;
               					break;
               				case 4:
               					ans=a/b;
               					break;
               				default:
               					printf("\n wrong choise");	
               
 				}              
               
                        printf("\nAnswer is:%d",ans);
						printf("\nEnter the Reply#");
						fgets(sendbuff,100,stdin);
                        if(send(connsd,sendbuff,strlen(sendbuff),0)>0)
                        printf("\n");
                        }
                     }
                }
        }
        close(connsd);
}


